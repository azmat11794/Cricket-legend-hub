
function getUrlParams() {
  const params = new URLSearchParams(window.location.search);
  return {
    id: params.get('id'),
    tableurl: params.get('tableurl'),
    achievements: params.get('achievements'),
    list: params.get('list') ? params.get('list').split(',') : [] ,
    name:params.get('name')
  };
}

function updatePlayerProfile() {
  const { id, tableurl, achievements, list,name } = getUrlParams();
if(name) {
  console.log(name);
  document.getElementById('namec').innerHTML=name;
}
  if(id){
    document.getElementById('image-id').src=`./res/img/l${id}.png`;
  }
 
  if (achievements) {
    document.querySelector('.player-details p').textContent = `Achievements : ${achievements}`;
  }

  
  if (tableurl) {
    const statsImage = document.querySelector('.stats-table');
    statsImage.src = tableurl;
    statsImage.alt = 'Player Stats Table';
  }

  
  const videoContainer = document.querySelector('.video-container');
  if (list && list.length > 0) {
    videoContainer.innerHTML = ''; // Clear existing videos
    list.forEach((videoUrl, index) => {
      const videoCard = document.createElement('div');
      videoCard.className = 'video-card';

      videoCard.innerHTML = `
        <iframe src="https://www.youtube.com/embed/${extractYouTubeID(videoUrl)}" frameborder="0" allowfullscreen></iframe>
      `;
      videoContainer.appendChild(videoCard);
    });
  }
}

function extractYouTubeID(url) {
  const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
  const match = url.match(regex);
  return match ? match[1] : null;
}

function handleComments() {
  const { id } = getUrlParams();
  const commentForm = document.getElementById('comment-form');
  const commentInput = document.getElementById('comment-input');
  const commentsList = document.getElementById('comments-list');

  function loadComments() {
    const comments = JSON.parse(localStorage.getItem('comments')) || {};
    const playerComments = comments[id] || []; 
    commentsList.innerHTML = ''; 

    playerComments.forEach(comment => {
      const li = document.createElement('li');
      li.textContent = comment;
      commentsList.appendChild(li);
    });
  }

  commentForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const newComment = commentInput.value.trim();

    if (newComment) {
      const comments = JSON.parse(localStorage.getItem('comments')) || {};
      const playerComments = comments[id] || [];
      playerComments.push(newComment);

      
      comments[id] = playerComments;
      localStorage.setItem('comments', JSON.stringify(comments));

      
      commentInput.value = '';
      loadComments();
    }
  });

  
  loadComments();
}

function initProfilePage() {
  updatePlayerProfile();
  handleComments();
}

document.addEventListener('DOMContentLoaded', initProfilePage);
